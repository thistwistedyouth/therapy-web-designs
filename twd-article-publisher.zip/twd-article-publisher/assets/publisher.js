(function () {
	'use strict';
	if (typeof TWD_AP === 'undefined') {
		return;
	}

	var state = {
		editingId: null,
		featuredMediaId: 0,
		activeTab: 'visual',
		dirty: false,
		categories: [],
	};

	var els = {};
	var featuredFrame = null;
	var inlineFrame = null;
	var savedRange = null;

	document.addEventListener('DOMContentLoaded', init);

	function init() {
		els.overlay = document.getElementById('twd-ap-overlay');
		if (!els.overlay) {
			return;
		}

		els.modal = document.getElementById('twd-ap-modal');
		els.modalTitle = document.getElementById('twd-ap-modal-title');
		els.status = document.getElementById('twd-ap-status');
		els.title = document.getElementById('twd-ap-title');
		els.featuredPreview = document.getElementById('twd-ap-featured-preview');
		els.featuredSelect = document.getElementById('twd-ap-featured-select');
		els.featuredRemove = document.getElementById('twd-ap-featured-remove');
		els.categories = document.getElementById('twd-ap-categories');
		els.tabVisual = document.getElementById('twd-ap-tab-visual');
		els.tabHtml = document.getElementById('twd-ap-tab-html');
		els.toolbar = document.getElementById('twd-ap-toolbar');
		els.visualEditor = document.getElementById('twd-ap-visual-editor');
		els.htmlEditor = document.getElementById('twd-ap-html-editor');
		els.excerpt = document.getElementById('twd-ap-excerpt');
		els.yoastWrap = document.getElementById('twd-ap-yoast-fields');
		els.yoastTitle = document.getElementById('twd-ap-yoast-title');
		els.yoastDesc = document.getElementById('twd-ap-yoast-desc');
		els.scheduleToggle = document.getElementById('twd-ap-schedule-toggle');
		els.scheduleDate = document.getElementById('twd-ap-schedule-date');
		els.draftBtn = document.getElementById('twd-ap-draft-btn');
		els.publishBtn = document.getElementById('twd-ap-publish-btn');
		els.closeBtn = document.getElementById('twd-ap-close-btn');
		els.newBtn = document.getElementById('twd-ap-new-btn');
		els.editBtn = document.getElementById('twd-ap-edit-btn');
		els.linkBtn = document.getElementById('twd-ap-link-btn');
		els.imageBtn = document.getElementById('twd-ap-image-btn');

		if (els.newBtn) {
			els.newBtn.addEventListener('click', function () {
				openModal('new');
			});
		}
		if (els.editBtn) {
			els.editBtn.addEventListener('click', function () {
				openModal('edit', TWD_AP.currentPostId);
			});
		}

		els.closeBtn.addEventListener('click', requestClose);
		els.overlay.addEventListener('click', function (e) {
			if (e.target === els.overlay) {
				requestClose();
			}
		});
		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && !els.overlay.hasAttribute('hidden')) {
				requestClose();
			}
		});

		els.tabVisual.addEventListener('click', function () {
			switchTab('visual');
		});
		els.tabHtml.addEventListener('click', function () {
			switchTab('html');
		});

		els.toolbar.addEventListener('click', function (e) {
			var btn = e.target.closest('button');
			if (!btn) {
				return;
			}
			els.visualEditor.focus();
			if (btn.dataset.cmd) {
				document.execCommand(btn.dataset.cmd, false, null);
			} else if (btn.dataset.block) {
				document.execCommand('formatBlock', false, '<' + btn.dataset.block + '>');
			}
			markDirty();
		});

		els.linkBtn.addEventListener('click', function () {
			els.visualEditor.focus();
			var url = window.prompt('Link URL (https://...)');
			if (url) {
				document.execCommand('createLink', false, url);
				markDirty();
			}
		});

		els.imageBtn.addEventListener('click', function () {
			saveSelection();
			openInlineImageFrame();
		});

		els.featuredSelect.addEventListener('click', openFeaturedImageFrame);
		els.featuredRemove.addEventListener('click', function () {
			state.featuredMediaId = 0;
			renderFeaturedPreview('');
			markDirty();
		});

		els.scheduleToggle.addEventListener('change', function () {
			els.scheduleDate.hidden = !this.checked;
			els.publishBtn.textContent = this.checked ? 'Schedule' : (state.editingId ? 'Update' : 'Publish');
			markDirty();
		});

		els.draftBtn.addEventListener('click', function () {
			submitPost('draft');
		});
		els.publishBtn.addEventListener('click', function () {
			submitPost(els.scheduleToggle.checked ? 'future' : 'publish');
		});

		[els.title, els.visualEditor, els.htmlEditor, els.excerpt, els.yoastTitle, els.yoastDesc].forEach(function (el) {
			el.addEventListener('input', markDirty);
		});

		fetchCategories();
	}

	function markDirty() {
		state.dirty = true;
	}

	function switchTab(tab) {
		if (tab === state.activeTab) {
			return;
		}
		if (tab === 'html') {
			els.htmlEditor.value = els.visualEditor.innerHTML.trim();
		} else {
			els.visualEditor.innerHTML = els.htmlEditor.value;
		}
		state.activeTab = tab;
		els.tabVisual.classList.toggle('twd-ap-tab-active', tab === 'visual');
		els.tabHtml.classList.toggle('twd-ap-tab-active', tab === 'html');
		els.visualEditor.hidden = tab !== 'visual';
		els.htmlEditor.hidden = tab !== 'html';
		els.toolbar.style.display = tab === 'visual' ? 'flex' : 'none';
	}

	function saveSelection() {
		var sel = window.getSelection();
		if (sel && sel.rangeCount > 0) {
			savedRange = sel.getRangeAt(0);
		}
	}

	function restoreSelection() {
		if (savedRange) {
			var sel = window.getSelection();
			sel.removeAllRanges();
			sel.addRange(savedRange);
		}
	}

	function openFeaturedImageFrame() {
		if (!window.wp || !wp.media) {
			return;
		}
		if (!featuredFrame) {
			featuredFrame = wp.media({ title: 'Choose Featured Image', multiple: false, library: { type: 'image' } });
			featuredFrame.on('select', function () {
				var att = featuredFrame.state().get('selection').first().toJSON();
				state.featuredMediaId = att.id;
				var url = (att.sizes && att.sizes.medium) ? att.sizes.medium.url : att.url;
				renderFeaturedPreview(url);
				markDirty();
			});
		}
		featuredFrame.open();
	}

	function openInlineImageFrame() {
		if (!window.wp || !wp.media) {
			return;
		}
		if (!inlineFrame) {
			inlineFrame = wp.media({ title: 'Insert Image', multiple: false, library: { type: 'image' } });
			inlineFrame.on('select', function () {
				var att = inlineFrame.state().get('selection').first().toJSON();
				var url = (att.sizes && att.sizes.medium) ? att.sizes.medium.url : att.url;
				els.visualEditor.focus();
				restoreSelection();
				document.execCommand('insertHTML', false, '<img src="' + url + '" alt="" />');
				markDirty();
			});
		}
		inlineFrame.open();
	}

	function renderFeaturedPreview(url) {
		if (url) {
			els.featuredPreview.style.backgroundImage = 'url(' + url + ')';
			els.featuredRemove.hidden = false;
		} else {
			els.featuredPreview.style.backgroundImage = '';
			els.featuredRemove.hidden = true;
		}
	}

	function fetchCategories() {
		fetch(TWD_AP.restUrl + '/categories', {
			headers: { 'X-WP-Nonce': TWD_AP.nonce },
		})
			.then(function (r) {
				return r.json();
			})
			.then(function (data) {
				state.categories = data;
				renderCategories([]);
			})
			.catch(function () {
				els.categories.innerHTML = '<span class="twd-ap-muted">Could not load categories.</span>';
			});
	}

	function renderCategories(checkedIds) {
		if (!state.categories.length) {
			els.categories.innerHTML = '<span class="twd-ap-muted">No categories yet.</span>';
			return;
		}
		els.categories.innerHTML = state.categories
			.map(function (cat) {
				var checked = checkedIds.indexOf(cat.id) !== -1 ? 'checked' : '';
				return '<label class="twd-ap-cat-item"><input type="checkbox" value="' + cat.id + '" ' + checked + ' /> ' + escapeHtml(cat.name) + '</label>';
			})
			.join('');
	}

	function getCheckedCategoryIds() {
		var boxes = els.categories.querySelectorAll('input[type="checkbox"]:checked');
		return Array.prototype.map.call(boxes, function (b) {
			return parseInt(b.value, 10);
		});
	}

	function escapeHtml(str) {
		var div = document.createElement('div');
		div.textContent = str;
		return div.innerHTML;
	}

	function resetForm() {
		els.title.value = '';
		els.visualEditor.innerHTML = '';
		els.htmlEditor.value = '';
		els.excerpt.value = '';
		els.yoastTitle.value = '';
		els.yoastDesc.value = '';
		els.scheduleToggle.checked = false;
		els.scheduleDate.hidden = true;
		els.scheduleDate.value = '';
		state.featuredMediaId = 0;
		renderFeaturedPreview('');
		switchTabImmediate('visual');
		state.dirty = false;
		hideStatus();
		els.yoastWrap.hidden = !TWD_AP.yoastEnabled;
		renderCategories([]);
	}

	function switchTabImmediate(tab) {
		state.activeTab = tab;
		els.tabVisual.classList.toggle('twd-ap-tab-active', tab === 'visual');
		els.tabHtml.classList.toggle('twd-ap-tab-active', tab === 'html');
		els.visualEditor.hidden = tab !== 'visual';
		els.htmlEditor.hidden = tab !== 'html';
		els.toolbar.style.display = tab === 'visual' ? 'flex' : 'none';
	}

	function openModal(mode, postId) {
		resetForm();
		if (mode === 'edit' && postId) {
			state.editingId = postId;
			els.modalTitle.textContent = 'Edit Article';
			els.publishBtn.textContent = 'Update';
			els.draftBtn.textContent = 'Save as Draft';
			loadPostForEdit(postId);
		} else {
			state.editingId = null;
			els.modalTitle.textContent = 'New Article';
			els.publishBtn.textContent = 'Publish';
			els.draftBtn.textContent = 'Save Draft';
		}
		els.overlay.hidden = false;
		document.body.style.overflow = 'hidden';
		setTimeout(function () {
			els.title.focus();
		}, 50);
	}

	function loadPostForEdit(id) {
		showStatus('Loading article…', false);
		fetch(TWD_AP.restUrl + '/posts/' + id, {
			headers: { 'X-WP-Nonce': TWD_AP.nonce },
		})
			.then(function (r) {
				if (!r.ok) {
					throw new Error('load-failed');
				}
				return r.json();
			})
			.then(function (data) {
				els.title.value = data.title || '';
				els.visualEditor.innerHTML = data.content_html || '';
				els.excerpt.value = data.excerpt || '';
				state.featuredMediaId = data.featured_media || 0;
				renderFeaturedPreview(data.featured_media_url || '');
				renderCategories(data.category_ids || []);
				if (TWD_AP.yoastEnabled) {
					els.yoastTitle.value = data.yoast_title || '';
					els.yoastDesc.value = data.yoast_desc || '';
				}
				state.dirty = false;
				hideStatus();
			})
			.catch(function () {
				showStatus('Could not load this article.', false);
			});
	}

	function requestClose() {
		if (state.dirty) {
			if (!window.confirm(TWD_AP.i18n.confirmClose)) {
				return;
			}
		}
		closeModal();
	}

	function closeModal() {
		els.overlay.hidden = true;
		document.body.style.overflow = '';
	}

	function showStatus(msg, ok) {
		els.status.textContent = msg;
		els.status.hidden = false;
		els.status.classList.toggle('twd-ap-status-ok', !!ok);
	}
	function hideStatus() {
		els.status.hidden = true;
	}

	function setBusy(busy) {
		els.draftBtn.disabled = busy;
		els.publishBtn.disabled = busy;
	}

	function submitPost(status) {
		var title = els.title.value.trim();
		if (!title) {
			showStatus('Please add a title before saving.', false);
			els.title.focus();
			return;
		}

		if (state.activeTab === 'html') {
			els.visualEditor.innerHTML = els.htmlEditor.value;
		}
		var contentHtml = els.visualEditor.innerHTML.trim();

		var payload = {
			title: title,
			content_html: contentHtml,
			excerpt: els.excerpt.value,
			category_ids: getCheckedCategoryIds(),
			featured_media: state.featuredMediaId,
			status: status,
		};

		if (status === 'future') {
			if (!els.scheduleDate.value) {
				showStatus('Please choose a date and time to schedule this article.', false);
				return;
			}
			payload.date = els.scheduleDate.value;
		}

		if (TWD_AP.yoastEnabled) {
			payload.yoast_title = els.yoastTitle.value;
			payload.yoast_desc = els.yoastDesc.value;
		}

		var url = TWD_AP.restUrl + '/posts';
		if (state.editingId) {
			url += '/' + state.editingId;
		}

		setBusy(true);
		showStatus(TWD_AP.i18n.saving, false);

		fetch(url, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
				'X-WP-Nonce': TWD_AP.nonce,
			},
			body: JSON.stringify(payload),
		})
			.then(function (r) {
				return r.json().then(function (data) {
					return { ok: r.ok, data: data };
				});
			})
			.then(function (result) {
				setBusy(false);
				if (!result.ok) {
					showStatus(result.data && result.data.message ? result.data.message : TWD_AP.i18n.error, false);
					return;
				}
				state.editingId = result.data.id;
				state.dirty = false;
				var label = status === 'draft' ? 'Draft saved.' : status === 'future' ? 'Article scheduled.' : 'Article published.';
				showStatus(label + ' You can keep editing or close this window.', true);
				els.modalTitle.textContent = 'Edit Article';
				els.draftBtn.textContent = 'Save as Draft';
				els.publishBtn.textContent = els.scheduleToggle.checked ? 'Schedule' : 'Update';
			})
			.catch(function () {
				setBusy(false);
				showStatus(TWD_AP.i18n.error, false);
			});
	}
})();
