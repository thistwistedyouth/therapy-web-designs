=== TWD Article Publisher ===
Contributors: therapywebdesigns
Tags: blog, articles, popup, editor
Requires at least: 5.9
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.12.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Lets approved users publish and edit blog articles from the live site in a popup, without going into wp-admin.

== Description ==

Adds a "New Article" button and, on any article the current user can edit, an "Edit This Article" button, both shown only to logged-in users on the site's front end. Both open the same popup, titled "Resource Maker", styled in a calm, therapy-friendly palette and showing the site's own logo (from Customize > Site Identity) if one is set.

The popup lets you:

* Write in a simple visual editor, or switch to an HTML tab and paste AI-formatted HTML
* Insert images inline from the Media Library or upload, and embed YouTube videos by pasting a link
* Click any inline image to align it left, center, right or full-width, and drag its corner handle to resize it
* Tag one or more categories (or add a new one on the fly), and add tags (comma separated, with autocomplete from existing tags)
* Set a featured image from the Media Library
* Write an excerpt
* Set the Yoast SEO title and meta description, if Yoast SEO is active
* Save as a draft, publish immediately, or schedule for a future date and time
* Tick "Feature this article" to pin it to the top of the `[twd_articles]` grid, ahead of newest-first
* Reopen and edit any article you have permission to edit, in the same popup
* While editing, an "Edit in WordPress" link opens the normal wp-admin post editor for that article in a new tab. Deliberately no "Edit with Elementor" link: switching a post into Elementor's builder mode can make it render from Elementor's own saved layout instead of post_content, which would silently stop reflecting future edits made through this popup.
* A third "Import JSON" tab alongside Visual and HTML: paste a JSON block (e.g. from TRD's Article Assist tool) with title, seo_title, meta_description, category, tags and html fields, and it fills in the title, excerpt, Yoast fields, category (matched or created), tags and body in one go, then switches you to the Visual tab so you can review and edit everything before saving. Nothing is locked: imported fields are exactly as editable as if you'd typed them.

All pasted or written HTML is cleaned on the server before saving: scripts, inline styles and anything unsafe are stripped, and any H1 is converted to H2 so the page's own post title stays the only H1.

Every published article can be viewed and shared as a swipe book: a full-screen, swipeable slide version of the same article, split automatically by heading and length. It is a live view generated on request, not a separate saved copy, so it always matches the article. Visit `[the article's URL]?twd_ap_swipebook=1`, or use the "View as a swipe book" link shown under every article, or the "Swipe book link" shown in the popup while editing a published article.

Use the `[twd_articles]` shortcode on any page for a fully interactive resources grid: a search box, category pills, "Load more" pagination -- all client-side, no page reload. Featured articles show first, then newest-first. Attributes: `category` (slug), `tag` (slug), `count` (default 9, per page), `columns` (default 3, max 4). Example: `[twd_articles count="9" columns="3"]`.

Give it an explicit `category` or `tag` attribute (e.g. `[twd_articles category="anxiety"]`) for a curated list without search/filters -- useful for a themed page. Or leave both off and drop the plain `[twd_articles]` shortcode straight onto a WordPress category or tag archive template (e.g. via Elementor Theme Builder): it automatically detects the current archive and shows only that category/tag's articles, so one shortcode works for every category page without hardcoding a slug per page.

An "Instructions for use" link at the bottom of the popup opens a built-in help screen covering the toolbar, categories/tags, the `[twd_articles]` shortcode (with a copy button), and a ready-to-copy AI prompt for drafting compatible HTML articles.

Every article page automatically gets its own built-in typography (headings, paragraphs, lists, blockquotes, images) so it reads well on any theme, even a bare Hello Elementor site with no custom Single Post template designed yet.

== Installation ==

1. Upload the twd-article-publisher folder to /wp-content/plugins/, or upload the zip via Plugins > Add New > Upload Plugin.
2. Activate the plugin.
3. Go to Settings > Article Publisher to choose which roles can use it, and pick a default category.
4. Visit the site while logged in as an allowed user. The "New Article" button appears bottom-right.

== Updates ==

Not distributed via WordPress.org. Every site running this plugin checks
https://github.com/thistwistedyouth/therapy-web-designs (a public repo)
for a newer version and shows the normal "update available" row in
Plugins, with a one-click update -- no manual re-zip-and-upload needed
per site. See includes/class-twd-ap-updater.php.

NEW (1.12.0): every published article can now be viewed and shared as a
swipe book. A "View as a swipe book" link appears under every article on
the public site, splitting it into swipeable slides (by heading and
length, no AI call needed) with a progress bar, swipe/arrow-key/button
navigation, and a Share button. It is always a live view of the current
article, generated fresh each time, so it never goes out of date and
needs nothing saved separately. While editing an existing published
article in the popup, a "Swipe book link" now also appears next to
"Edit in WordPress" for a quick way to grab the link right after
publishing.

FIX (1.11.1): scrolling inside the popup could bleed through and scroll
the page behind it once you reached the top or bottom of the popup's
own content. Now contained to the popup itself, and the page behind is
locked from scrolling more reliably across different themes.

NEW (1.11.0): the popup is renamed "Resource Maker" and restyled with a
softer, calmer colour palette (sage green, warm cream, dusty blue) in
place of the old bright blue. It now shows the site's own logo (from
Customize > Site Identity) next to the heading if one is set. The
"Instructions for use" link is now a small circular "?" icon in the
header instead of a text link at the bottom. The "Draft with Article
Assist" link is now a proper button, always visible in the header, not
just on the Import JSON tab.

NEW (1.10.2): the Import JSON tab has a "Draft with Article Assist"
link that opens Therapy Resource Directory's Article Assist tool in a
new tab, landing straight in the popup ready to write. Needs a Therapy
Resource Directory account (Resource Creator plan or above). A plain
new-tab link on purpose, not an embedded popup, since Article Assist
needs the visitor logged into that separate site.

NEW (1.10.1): a "Check for updates" link now sits right on the plugin's
own row on the main Plugins list (next to Deactivate), so you no longer
need to visit Settings > Article Publisher just to trigger an immediate
check. Clicking it forces the same instant recheck and shows the result
right there.

NEW (1.10.0): an "Import JSON" tab lets you paste a JSON block (title,
seo_title, meta_description, category, tags, html) and fill the whole
popup in one go, then review and edit before saving. Designed to pair
with TRD's Article Assist tool, but works with any JSON of that shape.
Visual stays the default tab; nothing is required to use JSON.

IMPORTANT FIX (1.9.1): the [twd_articles] grid was silently excluding
almost every article that had never been marked "Feature this article",
on every site, since v1.8.0. Update to this version as soon as possible.

Em dashes and en dashes are now automatically stripped from every field
(title, excerpt, tags, article body, category names, Yoast fields) before
saving, converted to a comma or dropped where they'd double up on other
punctuation. Handles both the real character and pasted HTML-entity forms.
This applies regardless of whether the text was typed, pasted from an AI
assistant, or generated by any AI tool, so it can never slip through.

Fixed: titles/excerpts with an apostrophe or the automatic "..." on a
trimmed excerpt could show as literal "&#8217;" or "&hellip;" text in the
[twd_articles] grid, instead of rendering as punctuation.

A "Check for updates" button on Settings > Article Publisher forces an
immediate check instead of waiting for the automatic 12-hour cycle.

To ship a new version to every client site: bump the Version header and
TWD_AP_VERSION here, then update dist/twd-article-publisher-update.json
(version, changelog) and overwrite dist/twd-article-publisher-latest.zip
with a fresh build (packaging command below), and push. Sites pick it up
within 12 hours automatically, or immediately via Plugins > "Check again".

== Frequently Asked Questions ==

= Does this replace the normal WordPress editor? =

No. Everything it creates is a normal WordPress post, still editable in wp-admin as usual. This is an additional, quicker way in for people who don't need the full editor.

= Where do scheduled times come from? =

The date and time you pick are treated as the site's own local time (Settings > General > Timezone in wp-admin).

= Does it work with any theme? =

Yes. It adds its own floating buttons and popup independently of the theme.
