<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Display settings for the [twd_articles] grouped-by-category landing view:
 * how many category sections show, how many posts in each, their order, and
 * whether thumbnails show at all. A separate option and class from
 * TWD_AP_Settings on purpose, since that one is about who can use the editor
 * popup, a different concern from how the public grid displays.
 */
class TWD_AP_Grid_Settings {

	const OPTION_KEY = 'twd_ap_grid_settings';

	public static function get() {
		$defaults = array(
			'category_order'     => array(),
			'categories_count'   => 4,
			'posts_per_category' => 6,
			'show_thumbnails'    => true,
			'read_more_color'    => '#1d4ed8',
			'accent_color'       => '#2563eb',
			// Which categories the "Browse by topic" row under the grid lists:
			// 'all' (every real, non-empty category, the default, so new
			// categories appear on their own) or an array of category IDs.
			'topic_category_ids' => 'all',
			// Article look (1.38.0): how a published article reads. Empty
			// colours and the 'system' / 'medium' / 'normal' choices mean "the
			// plugin's own typography", and then nothing is printed at all,
			// so a site that never touches these looks exactly as before.
			// Call to action (1.38.0): empty and switched off everywhere until
			// the owner fills it in and ticks where it should show.
			// Category intro (1.38.0): print a category page's own Description above
			// its grid. Off until the owner ticks it, because many themes already
			// print the description themselves and it would show twice.
			'intro_show'         => false,
			'cta_heading'        => '',
			'cta_text'           => '',
			'cta_button_label'   => '',
			'cta_button_url'     => '',
			'cta_show_grid'      => false,
			'cta_show_categories' => false,
			'cta_show_index'     => false,
			'cta_show_articles'  => false,
			'look_text_color'    => '',
			'look_heading_color' => '',
			'look_link_color'    => '',
			'look_quote_color'   => '',
			'look_font'          => 'system',
			'look_size'          => 'medium',
			'look_spacing'       => 'normal',
			'swipebook_color'    => '#5b8a72',
			'swipebook_heading'  => '',
			'swipebook_label'    => 'Swipe Book',
			'swipebook_logo_id'  => 0,
			'swipebook_logo_bg'  => 'light',
			'swipebook_export_branding' => true,
			'profile_photo_id'   => 0,
			'profile_name'       => '',
			'profile_bio'        => '',
			'profile_link_url'   => '',
			'profile_link_label' => '',
		);
		$saved = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		return wp_parse_args( $saved, $defaults );
	}

	public static function sanitize( $input ) {
		$current = self::get();

		$output = array(
			'category_order'     => $current['category_order'],
			'categories_count'   => $current['categories_count'],
			'posts_per_category' => $current['posts_per_category'],
			'show_thumbnails'    => $current['show_thumbnails'],
			'read_more_color'    => $current['read_more_color'],
			'accent_color'       => $current['accent_color'],
			'topic_category_ids' => $current['topic_category_ids'],
			'intro_show'         => $current['intro_show'],
			'cta_heading'        => $current['cta_heading'],
			'cta_text'           => $current['cta_text'],
			'cta_button_label'   => $current['cta_button_label'],
			'cta_button_url'     => $current['cta_button_url'],
			'cta_show_grid'      => $current['cta_show_grid'],
			'cta_show_categories' => $current['cta_show_categories'],
			'cta_show_index'     => $current['cta_show_index'],
			'cta_show_articles'  => $current['cta_show_articles'],
			'look_text_color'    => $current['look_text_color'],
			'look_heading_color' => $current['look_heading_color'],
			'look_link_color'    => $current['look_link_color'],
			'look_quote_color'   => $current['look_quote_color'],
			'look_font'          => $current['look_font'],
			'look_size'          => $current['look_size'],
			'look_spacing'       => $current['look_spacing'],
			'swipebook_color'    => $current['swipebook_color'],
			'swipebook_heading'  => $current['swipebook_heading'],
			'swipebook_label'    => $current['swipebook_label'],
			'swipebook_logo_id'  => $current['swipebook_logo_id'],
			'swipebook_logo_bg'  => $current['swipebook_logo_bg'],
			'swipebook_export_branding' => $current['swipebook_export_branding'],
			'profile_photo_id'   => $current['profile_photo_id'],
			'profile_name'       => $current['profile_name'],
			'profile_bio'        => $current['profile_bio'],
			'profile_link_url'   => $current['profile_link_url'],
			'profile_link_label' => $current['profile_link_label'],
		);

		if ( isset( $input['category_order'] ) && is_array( $input['category_order'] ) ) {
			$output['category_order'] = array_values( array_filter( array_map( 'absint', $input['category_order'] ) ) );
		}
		if ( isset( $input['categories_count'] ) ) {
			$output['categories_count'] = max( 1, min( 12, absint( $input['categories_count'] ) ) );
		}
		if ( isset( $input['posts_per_category'] ) ) {
			$output['posts_per_category'] = max( 1, min( 24, absint( $input['posts_per_category'] ) ) );
		}
		if ( isset( $input['show_thumbnails'] ) ) {
			$output['show_thumbnails'] = (bool) $input['show_thumbnails'];
		}
		if ( isset( $input['read_more_color'] ) ) {
			$color = sanitize_hex_color( $input['read_more_color'] );
			if ( $color ) {
				$output['read_more_color'] = $color;
			}
		}
		if ( isset( $input['accent_color'] ) ) {
			$color = sanitize_hex_color( $input['accent_color'] );
			if ( $color ) {
				$output['accent_color'] = $color;
			}
		}
		if ( isset( $input['topic_category_ids'] ) ) {
			if ( 'all' === $input['topic_category_ids'] ) {
				$output['topic_category_ids'] = 'all';
			} elseif ( is_array( $input['topic_category_ids'] ) ) {
				$output['topic_category_ids'] = array_values( array_unique( array_filter( array_map( 'absint', $input['topic_category_ids'] ) ) ) );
			}
		}
		foreach ( array( 'look_text_color', 'look_heading_color', 'look_link_color', 'look_quote_color' ) as $key ) {
			if ( isset( $input[ $key ] ) ) {
				// An empty value clears the colour back to the plugin default.
				$color            = '' === $input[ $key ] ? '' : sanitize_hex_color( $input[ $key ] );
				$output[ $key ]   = $color ? $color : ( '' === $input[ $key ] ? '' : $output[ $key ] );
			}
		}
		if ( isset( $input['intro_show'] ) ) {
			$output['intro_show'] = (bool) $input['intro_show'];
		}
		if ( isset( $input['cta_heading'] ) ) {
			$output['cta_heading'] = mb_substr( TWD_AP_Sanitizer::strip_dashes( sanitize_text_field( $input['cta_heading'] ) ), 0, 120 );
		}
		if ( isset( $input['cta_text'] ) ) {
			$output['cta_text'] = mb_substr( TWD_AP_Sanitizer::strip_dashes( sanitize_textarea_field( $input['cta_text'] ) ), 0, 500 );
		}
		if ( isset( $input['cta_button_label'] ) ) {
			$output['cta_button_label'] = mb_substr( TWD_AP_Sanitizer::strip_dashes( sanitize_text_field( $input['cta_button_label'] ) ), 0, 40 );
		}
		if ( isset( $input['cta_button_url'] ) ) {
			// http, https, mailto and tel only; anything else becomes empty.
			$output['cta_button_url'] = esc_url_raw( trim( (string) $input['cta_button_url'] ), array( 'http', 'https', 'mailto', 'tel' ) );
		}
		foreach ( array( 'cta_show_grid', 'cta_show_categories', 'cta_show_index', 'cta_show_articles' ) as $key ) {
			if ( isset( $input[ $key ] ) ) {
				$output[ $key ] = (bool) $input[ $key ];
			}
		}
		$choices = array(
			'look_font'    => array( 'system', 'serif', 'theme' ),
			'look_size'    => array( 'medium', 'large' ),
			'look_spacing' => array( 'compact', 'normal', 'relaxed' ),
		);
		foreach ( $choices as $key => $allowed ) {
			if ( isset( $input[ $key ] ) && in_array( $input[ $key ], $allowed, true ) ) {
				$output[ $key ] = $input[ $key ];
			}
		}
		if ( isset( $input['swipebook_color'] ) ) {
			$color = sanitize_hex_color( $input['swipebook_color'] );
			if ( $color ) {
				$output['swipebook_color'] = $color;
			}
		}
		if ( isset( $input['swipebook_heading'] ) ) {
			$output['swipebook_heading'] = sanitize_text_field( $input['swipebook_heading'] );
		}
		if ( isset( $input['swipebook_label'] ) ) {
			$label = sanitize_text_field( $input['swipebook_label'] );
			$output['swipebook_label'] = '' !== $label ? $label : 'Swipe Book';
		}
		if ( isset( $input['swipebook_logo_id'] ) ) {
			$output['swipebook_logo_id'] = absint( $input['swipebook_logo_id'] );
		}
		if ( isset( $input['swipebook_logo_bg'] ) && in_array( $input['swipebook_logo_bg'], array( 'none', 'light', 'dark' ), true ) ) {
			$output['swipebook_logo_bg'] = $input['swipebook_logo_bg'];
		}
		if ( isset( $input['swipebook_export_branding'] ) ) {
			$output['swipebook_export_branding'] = (bool) $input['swipebook_export_branding'];
		}
		if ( isset( $input['profile_photo_id'] ) ) {
			$output['profile_photo_id'] = absint( $input['profile_photo_id'] );
		}
		if ( isset( $input['profile_name'] ) ) {
			$output['profile_name'] = sanitize_text_field( $input['profile_name'] );
		}
		if ( isset( $input['profile_bio'] ) ) {
			$output['profile_bio'] = sanitize_textarea_field( $input['profile_bio'] );
		}
		if ( isset( $input['profile_link_url'] ) ) {
			$output['profile_link_url'] = esc_url_raw( $input['profile_link_url'] );
		}
		if ( isset( $input['profile_link_label'] ) ) {
			$output['profile_link_label'] = sanitize_text_field( $input['profile_link_label'] );
		}

		return $output;
	}

	public static function save( $input ) {
		update_option( self::OPTION_KEY, self::sanitize( $input ) );
	}
}
