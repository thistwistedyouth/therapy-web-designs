<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Gives published articles readable typography on any theme, independent of
 * whether the site has built its own Single Post template. Unlike the popup's
 * own CSS (only loaded for logged-in editors via TWD_AP_Frontend), this loads
 * for every visitor, because they're the ones actually reading the article.
 */
class TWD_AP_Article_Style {

	private static $instance = null;
	private static $wrapped = false;
	private static $header_done = false;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'maybe_enqueue' ) );
		add_filter( 'the_content', array( $this, 'wrap_content' ), 20 );
		// After WordPress's own paragraph and quote tidying (also priority 10,
		// registered earlier) and before the swipe book buttons are added (11
		// and 15), so the buttons' own words are left alone.
		add_filter( 'the_content', array( $this, 'tidy_content' ), 10 );
		// 1.50.0: the article's own header block (lead line, details, picture). After the
		// swipe book buttons were put at the start (11) so it sits above them.
		add_filter( 'the_content', array( $this, 'prepend_header' ), 12 );
		add_filter( 'body_class', array( $this, 'banner_body_class' ) );
	}

	public function maybe_enqueue() {
		if ( is_admin() || ! is_singular( 'post' ) ) {
			return;
		}
		self::enqueue();
	}

	/**
	 * The article stylesheet and script. Also called by the shortcodes that
	 * print article furniture (the related block, the swipe book button), so
	 * they are styled on a page that is not a single article too.
	 */
	public static function enqueue() {
		wp_enqueue_style(
			'twd-ap-article-style',
			TWD_AP_URL . 'assets/article-content.css',
			array(),
			TWD_AP_VERSION
		);

		wp_enqueue_script(
			'twd-ap-article-style',
			TWD_AP_URL . 'assets/article-content.js',
			array(),
			TWD_AP_VERSION,
			true
		);
	}

	/**
	 * "Tidy line endings" (Article look): keeps a one or two letter word with
	 * the word after it, so a line never ends on "so", "we" or "an". Only the
	 * article being shown on its own page, and only when the owner has left it
	 * ticked (it is, by default). The stored article is never touched.
	 */
	public function tidy_content( $content ) {
		if ( is_admin() || ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}
		if ( empty( TWD_AP_Grid_Settings::get()['look_tidy_lines'] ) ) {
			return $content;
		}
		// The rule is about English: short words that should not end a line. In
		// another language the same rule would glue most of a sentence together
		// (Hebrew, Arabic, Dutch), so it only runs on an English site unless a
		// site says otherwise with the twd_ap_tidy_lines filter.
		$english = 0 === strpos( strtolower( (string) get_locale() ), 'en' );
		if ( ! apply_filters( 'twd_ap_tidy_lines', $english, $content ) ) {
			return $content;
		}
		return self::tidy_lines( $content );
	}

	/** The most one or two letter words glued in a row (see tidy_lines()). */
	const TIDY_CHAIN = 5;

	/**
	 * The text of an HTML string with a non-breaking space after every word
	 * of one or two letters that is followed by a space. Tags and their
	 * attributes are left exactly as they are, and so is everything inside
	 * pre, code, kbd, samp, script, style and textarea. A word counts only if
	 * it stands alone (not the end of a longer word, not after an apostrophe
	 * or hyphen, apostrophe entities included). Shortcode syntax in square
	 * brackets ([button text="Go to top"]) is left alone, since shortcodes are
	 * read after this runs. At most TIDY_CHAIN short words in a row are glued
	 * (a longer run of them would be one unbreakable block too wide for a
	 * narrow screen). If the text is not valid UTF-8 it is returned unchanged.
	 */
	public static function tidy_lines( $html ) {
		$parts = preg_split( '/(<[^>]*>)/', (string) $html, -1, PREG_SPLIT_DELIM_CAPTURE );
		if ( ! is_array( $parts ) ) {
			return $html;
		}
		$skip = 0;
		foreach ( $parts as $i => $part ) {
			if ( '' === $part ) {
				continue;
			}
			if ( '<' === $part[0] ) {
				if ( preg_match( '/^<(\/?)(pre|code|kbd|samp|script|style|textarea)\b/i', $part, $m ) && '/>' !== substr( $part, -2 ) ) {
					$skip = max( 0, $skip + ( '/' === $m[1] ? -1 : 1 ) );
				}
				continue;
			}
			if ( $skip > 0 ) {
				continue;
			}
			// Text outside shortcode syntax only: the odd pieces are shortcodes.
			$bits = preg_split( '/(\[\/?[A-Za-z_][\w-]*(?:\s[^\[\]]*)?\])/', $part, -1, PREG_SPLIT_DELIM_CAPTURE );
			if ( ! is_array( $bits ) ) {
				return $html;
			}
			foreach ( $bits as $k => $bit ) {
				if ( 1 === $k % 2 || '' === $bit ) {
					continue;
				}
				$done = self::glue_short_words( $bit );
				if ( null === $done ) {
					return $html; // not valid UTF-8: leave the whole article as it is
				}
				$bits[ $k ] = $done;
			}
			$parts[ $i ] = implode( '', $bits );
		}
		return implode( '', $parts );
	}

	/**
	 * One piece of text: the glue itself. Returns null if the text is not valid
	 * UTF-8. The apostrophe entities are checked too: wptexturize has already
	 * turned "it's" into "it&#8217;s" by the time this runs, and the "s" is not
	 * a word of its own.
	 */
	private static function glue_short_words( $text ) {
		$end = -1;   // where the previous glued word ended: a match starting there is in the same run
		$run = 0;
		return preg_replace_callback(
			'/(?<![\p{L}\p{N}\'\x{2019}\-])(?<!&#8217;)(?<!&#8216;)(?<!&#039;)(?<!&#39;)(?<!&#x2019;)(?<!&rsquo;)(?<!&lsquo;)(?<!&apos;)(\p{L}{1,2}) (?=\S|$)/u',
			function ( $m ) use ( &$end, &$run ) {
				$start = $m[0][1];
				$run   = $start === $end ? $run + 1 : 1;
				$end   = $start + strlen( $m[0][0] );
				if ( $run > self::TIDY_CHAIN ) {
					$run = 0; // leave this space as it is; the next short word starts a new run
					return $m[0][0];
				}
				return $m[1][0] . '&nbsp;';
			},
			$text,
			-1,
			$count,
			PREG_OFFSET_CAPTURE
		);
	}

	/**
	 * 1.50.0: under the theme's own title, a lead line (the article's excerpt, only when
	 * someone wrote one: an automatic excerpt would just repeat the first paragraph), a
	 * details line (topic, date, minutes to read) and the featured picture. Each part
	 * appears only when it exists. Switch the whole block off with
	 * add_filter( 'twd_ap_article_header', '__return_false' ).
	 */
	public function prepend_header( $content ) {
		if ( self::$header_done || is_admin() || ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}
		if ( ! apply_filters( 'twd_ap_article_header', true ) ) {
			return $content;
		}
		self::$header_done = true;
		return self::header_html( get_post() ) . $content;
	}

	public static function header_html( $post ) {
		$out  = '';
		// 1.52.2: the per-article tick _twd_ap_hide_lead hides this lead line on the article page only.
		// The excerpt is still used by the grid cards, the SEO description and the swipe book.
		$lead = ( has_excerpt( $post ) && ! get_post_meta( $post->ID, '_twd_ap_hide_lead', true ) ) ? trim( wp_strip_all_tags( get_the_excerpt( $post ) ) ) : '';
		if ( '' !== $lead ) {
			$out .= '<p class="twd-ap-article-lead">' . esc_html( $lead ) . '</p>';
		}
		$bits  = array();
		$topic = class_exists( 'TWD_AP_Related' ) ? TWD_AP_Related::topic_for( $post->ID ) : null;
		if ( $topic ) {
			$bits[] = '<span class="twd-ap-article-topic">' . esc_html( html_entity_decode( $topic->name, ENT_QUOTES, 'UTF-8' ) ) . '</span>';
		}
		$bits[] = '<span>' . esc_html( get_the_date( '', $post ) ) . '</span>';
		$words  = str_word_count( wp_strip_all_tags( strip_shortcodes( (string) $post->post_content ) ) );
		if ( $words > 0 ) {
			$bits[] = '<span>' . (int) max( 1, ceil( $words / 200 ) ) . ' min read</span>';
		}
		$out .= '<p class="twd-ap-article-meta">' . implode( '<span class="twd-ap-article-meta-dot" aria-hidden="true">&middot;</span>', $bits ) . '</p>';
		$pic_id = self::top_image_id( $post );
		if ( $pic_id && ! self::banner_active( $post ) ) {
			$img = wp_get_attachment_image( $pic_id, 'large', false, array( 'class' => 'twd-ap-article-hero-img', 'loading' => 'eager' ) );
			if ( '' !== $img ) {
				$out .= '<figure class="twd-ap-article-hero">' . $img . '</figure>';
			}
		}
		return self::banner_html( $post ) . '<div class="twd-ap-article-header">' . $out . '</div>';
	}

	/**
	 * 1.51.0: the picture for the top of an article: the one chosen for it in the editor
	 * (_twd_ap_top_image), otherwise the featured image. A picture chosen for the article is shown
	 * even when the site-wide tick (article_hero) is off: that tick only decides whether articles
	 * show their featured image by default. This article's own tick (_twd_ap_hide_hero) hides either.
	 * 0 when there is none or the stored id is no longer an image.
	 */
	public static function top_image_id( $post ) {
		$post = get_post( $post );
		if ( ! $post || get_post_meta( $post->ID, '_twd_ap_hide_hero', true ) ) {
			return 0;
		}
		$own = (int) get_post_meta( $post->ID, '_twd_ap_top_image', true );
		if ( $own && wp_attachment_is_image( $own ) ) {
			return $own;
		}
		if ( empty( TWD_AP_Grid_Settings::get()['article_hero'] ) ) {
			return 0;
		}
		$thumb = (int) get_post_thumbnail_id( $post );
		return ( $thumb && wp_attachment_is_image( $thumb ) ) ? $thumb : 0;
	}

	/** True when this article shows its picture as a full width banner above the title. */
	public static function banner_active( $post ) {
		$post = get_post( $post );
		return $post && get_post_meta( $post->ID, '_twd_ap_top_full', true ) && self::top_image_id( $post ) > 0;
	}

	/**
	 * The banner: a wide strip, picture cropped from the centre. It is printed first in the article
	 * text, and a one-line script placed straight after it moves it in front of the theme's own title
	 * block (Hello Elementor's .page-header, or the h1 .entry-title) before the page is painted.
	 * With no script, or a theme whose title cannot be found, it stays where it is, still full width.
	 */
	public static function banner_html( $post ) {
		if ( ! self::banner_active( $post ) ) {
			return '';
		}
		$img = wp_get_attachment_image( self::top_image_id( $post ), 'full', false, array( 'class' => 'twd-ap-article-banner-img', 'loading' => 'eager', 'sizes' => '100vw' ) );
		if ( '' === $img ) {
			return '';
		}
		return '<figure class="twd-ap-article-banner">' . $img . '</figure>' .
			'<script>(function(){var d=document.documentElement;function w(){d.style.setProperty("--twd-ap-vw",d.clientWidth+"px");}w();window.addEventListener("resize",w);var s=document.currentScript,b=s&&s.previousElementSibling;if(!b||!b.classList.contains("twd-ap-article-banner"))return;var h=document.querySelector("main .page-header")||document.querySelector("h1.entry-title");var t=h&&(h.closest(".page-header")||h);if(t&&t.parentNode&&!t.contains(b)){t.parentNode.insertBefore(b,t);}})();</script>';
	}

	public function banner_body_class( $classes ) {
		if ( is_singular( 'post' ) && self::banner_active( get_queried_object_id() ) ) {
			$classes[] = 'twd-ap-has-banner';
		}
		return $classes;
	}

	public function wrap_content( $content ) {
		if ( self::$wrapped || is_admin() || ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}
		self::$wrapped = true;
		$style = self::look_style();
		return '<div class="twd-ap-article-content"' . ( '' !== $style ? ' style="' . esc_attr( $style ) . '"' : '' ) . '>' . $content . '</div>';
	}

	/**
	 * The owner's "Article look" choices as CSS custom properties for the
	 * article wrapper. Only what the owner has changed is returned, so a
	 * site that never touched the settings gets no style attribute and
	 * keeps the stylesheet's own defaults. Every value is a validated hex
	 * colour or one of a fixed list of font, size and spacing choices.
	 */
	public static function look_style() {
		$s    = TWD_AP_Grid_Settings::get();
		$vars = array();
		$map  = array(
			'look_text_color'    => '--twd-ap-content-text',
			'look_heading_color' => '--twd-ap-content-heading',
			'look_link_color'    => '--twd-ap-content-link',
			'look_quote_color'   => '--twd-ap-content-quote',
		);
		foreach ( $map as $key => $var ) {
			if ( ! empty( $s[ $key ] ) && sanitize_hex_color( $s[ $key ] ) ) {
				$vars[] = $var . ':' . $s[ $key ];
			}
		}
		if ( 'serif' === $s['look_font'] ) {
			$vars[] = '--twd-ap-content-font:Georgia, "Times New Roman", Times, serif';
			$vars[] = '--twd-ap-content-heading-font:Georgia, "Times New Roman", Times, serif';
		} elseif ( 'theme' === $s['look_font'] ) {
			// Not a variable: a CSS-wide keyword such as inherit cannot be the
			// value of a custom property (it would mean "inherit the
			// variable"). Inline !important beats the stylesheet's own.
			$vars[] = 'font-family:inherit !important';
			$vars[] = '--twd-ap-content-heading-font:inherit';
		}
		if ( 'large' === $s['look_size'] ) {
			$vars[] = '--twd-ap-content-size:19px';
			$vars[] = '--twd-ap-content-size-m:17px';
		}
		// 1.48.0: heading sizes for the text of an article. The phone size is the same
		// choice scaled down, as the plugin's own sizes are (26 to 22, 21 to 19).
		foreach ( array( 2, 3, 4 ) as $level ) {
			$px = (int) ( $s[ 'look_h' . $level . '_size' ] ?? 0 );
			if ( $px >= TWD_AP_Grid_Settings::HEADING_MIN && $px <= TWD_AP_Grid_Settings::HEADING_MAX ) {
				$vars[] = '--twd-ap-content-h' . $level . '-size:' . $px . 'px';
				$vars[] = '--twd-ap-content-h' . $level . '-size-m:' . max( TWD_AP_Grid_Settings::HEADING_MIN, (int) round( $px * 0.85 ) ) . 'px';
			}
		}
		$leading = array( 'compact' => '1.55', 'relaxed' => '1.95' );
		if ( isset( $leading[ $s['look_spacing'] ] ) ) {
			$vars[] = '--twd-ap-content-leading:' . $leading[ $s['look_spacing'] ];
		}
		return implode( ';', $vars ) . ( $vars ? ';' : '' );
	}
}
