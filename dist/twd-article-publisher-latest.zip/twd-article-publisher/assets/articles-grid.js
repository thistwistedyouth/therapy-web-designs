(function () {
	'use strict';

	var PLACEHOLDER_SVG = '<svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="currentColor" stroke-width="1.5">' +
		'<rect x="3" y="4" width="18" height="16" rx="2" /><circle cx="8.5" cy="9.5" r="1.5" /><path d="M21 16l-5.5-5.5-4 4L8 11l-5 5" /></svg>';

	// Same box shape as a real .twd-ap-article-card (thumb height, body
	// padding, line count) so swapping skeleton cards for real ones never
	// changes the grid's height -- that swap, not the shimmer itself, is
	// what read as the page "resizing" while articles loaded in.
	function skeletonCardHtml() {
		return '<div class="twd-ap-article-card twd-ap-skeleton-card" aria-hidden="true">' +
			'<span class="twd-ap-article-thumb twd-ap-skeleton-block"></span>' +
			'<span class="twd-ap-article-body">' +
				'<span class="twd-ap-skeleton-line twd-ap-skeleton-line-date"></span>' +
				'<span class="twd-ap-skeleton-line twd-ap-skeleton-line-title"></span>' +
				'<span class="twd-ap-skeleton-line twd-ap-skeleton-line-title-short"></span>' +
				'<span class="twd-ap-skeleton-line twd-ap-skeleton-line-excerpt"></span>' +
				'<span class="twd-ap-skeleton-line twd-ap-skeleton-line-excerpt"></span>' +
			'</span>' +
		'</div>';
	}
	function skeletonCardsHtml(count) {
		var html = '';
		for (var i = 0; i < count; i++) { html += skeletonCardHtml(); }
		return html;
	}

	document.addEventListener('DOMContentLoaded', function () {
		var containers = document.querySelectorAll('.twd-ap-articles');
		Array.prototype.forEach.call(containers, initGrid);
	});

	function initGrid(root) {
		var config;
		try {
			config = JSON.parse(root.dataset.config);
		} catch (e) {
			return;
		}

		var groupsEl    = root.querySelector('.twd-ap-articles-groups');
		var gridEl      = root.querySelector('.twd-ap-articles-grid');
		var emptyEl     = root.querySelector('.twd-ap-articles-empty');
		var loadMoreBtn = root.querySelector('.twd-ap-articles-loadmore');
		var searchEl    = root.querySelector('.twd-ap-articles-search');
		var selectEl    = root.querySelector('.twd-ap-articles-category-select');
		var settingsBtn = root.querySelector('.twd-ap-articles-settings-btn');

		var state = {
			search: '',
			category: config.category || '',
			tag: config.tag || '',
			offset: 0,
			loading: false,
			showThumbnails: true,
			// Set once, synchronously, from config.manyArticles -- baked into
			// this page's own server-rendered HTML (class-twd-ap-shortcode.php),
			// not fetched over REST after load. Nothing async, nothing that
			// can race, nothing that can go stale independently of the page
			// itself. Only ever re-read from the REST /grid-settings response
			// after that (loadThumbnailSetting), in case an article gets
			// published/deleted without a full page reload.
			manyArticles: !!config.manyArticles,
		};

		// Matches the 12 hard-coded in class-twd-ap-shortcode.php, for the
		// re-check against a fresh /grid-settings response further down.
		var GROUP_THRESHOLD = 12;

		// The grouped-by-category landing view only applies to the default,
		// unfiltered usage of the shortcode (no explicit category/tag
		// attribute) -- a page like [twd_articles category="anxiety"] always
		// shows its own flat, paginated list, same as before this feature --
		// and, on top of that, only once there's enough content for split
		// sections to make sense. A handful of articles reads better as one
		// plain list than split into thin, mostly-empty category sections,
		// each with its own "Load more" that would come back empty anyway.
		function canGroup() {
			return config.showFilters && '' === state.category && '' === state.tag && state.manyArticles;
		}

		if (config.showFilters && selectEl) {
			loadFacets();
		}

		// state.manyArticles is already known synchronously (from the page's
		// own server-rendered config), so the very first render doesn't wait
		// on any fetch to decide grouped vs. flat. loadThumbnailSetting still
		// runs, for thumbnails/read-more colour and to catch an article
		// published or deleted since this page itself was rendered, but it
		// no longer gates this decision.
		if (canGroup()) {
			fetchGrouped();
		} else {
			fetchArticles(true);
		}
		loadThumbnailSetting();

		if (searchEl) {
			var searchTimer = null;
			searchEl.addEventListener('input', function () {
				clearTimeout(searchTimer);
				searchTimer = setTimeout(function () {
					state.search = searchEl.value.trim();
					state.offset = 0;
					switchToFlatIfNeeded();
				}, 350);
			});
		}

		if (selectEl) {
			selectEl.addEventListener('change', function () {
				state.category = selectEl.value;
				state.offset = 0;
				// The empty-value "Show all" option means a full return to
				// the default landing view, not just clearing the category
				// filter while a search is still active.
				if (!state.category && searchEl) {
					state.search = '';
					searchEl.value = '';
				}
				switchToFlatIfNeeded();
			});
		}

		loadMoreBtn.addEventListener('click', function () {
			state.offset += config.count;
			fetchArticles(false);
		});

		if (settingsBtn) {
			settingsBtn.addEventListener('click', function () {
				openGridSettings(root, config, function () {
					// Settings changed: re-render whichever view is current.
					loadThumbnailSetting(function () {
						if (!state.search && !state.category && canGroup()) {
							fetchGrouped();
						} else {
							fetchArticles(true);
						}
					});
				});
			});
		}

		function switchToFlatIfNeeded() {
			if (!canGroup()) {
				fetchArticles(true);
				return;
			}
			var isDefault = !state.search && !state.category;
			if (isDefault) {
				fetchGrouped();
			} else {
				fetchArticles(true);
			}
		}

		function loadThumbnailSetting(done) {
			fetch(config.restUrl + '/grid-settings', { cache: 'no-store' })
				.then(function (r) { return r.json(); })
				.then(function (data) {
					state.showThumbnails = data && false !== data.show_thumbnails;
					root.classList.toggle('twd-ap-no-thumbnails', !state.showThumbnails);
					if (data && data.read_more_color) {
						root.style.setProperty('--twd-ap-readmore-color', data.read_more_color);
					}
					if (data && data.accent_color) {
						root.style.setProperty('--twd-ap-accent-color', data.accent_color);
					}
					var total = data && data.total_articles;
					state.manyArticles = 'number' === typeof total && total > GROUP_THRESHOLD;
					// Fewer than the threshold: fetch enough in one go to
					// show every article on this site, so "Load more" never
					// has a next page to offer.
					if (!state.manyArticles && 'number' === typeof total) {
						config.count = Math.max(config.count, total);
					}
					if (done) { done(); }
				})
				.catch(function () {
					if (done) { done(); }
				});
		}

		function loadFacets() {
			fetch(config.restUrl + '/articles/facets', { cache: 'no-store' })
				.then(function (r) { return r.json(); })
				.then(function (data) {
					renderCategorySelect(data.categories || []);
				})
				.catch(function () {});
		}

		function renderCategorySelect(categories) {
			var html = '';
			categories.forEach(function (cat) {
				html += '<option value="' + escapeHtml(cat.slug) + '">' + escapeHtml(cat.name) + '</option>';
			});
			html += '<option value="">Show all</option>';
			selectEl.innerHTML = html;
			selectEl.value = state.category;
		}

		function fetchGrouped() {
			if (state.loading) { return; }
			state.loading = true;
			groupsEl.innerHTML =
				'<div class="twd-ap-articles-group">' +
					'<span class="twd-ap-skeleton-line twd-ap-skeleton-line-heading"></span>' +
					'<div class="twd-ap-articles-grid" style="--twd-ap-articles-columns: 3;">' + skeletonCardsHtml(3) + '</div>' +
				'</div>';
			gridEl.hidden = true;
			emptyEl.hidden = true;
			loadMoreBtn.hidden = true;

			fetch(config.restUrl + '/articles/grouped', { cache: 'no-store' })
				.then(function (r) { return r.json(); })
				.then(function (data) {
					state.loading = false;
					var groups = data.groups || [];
					if (!groups.length) {
						groupsEl.innerHTML = '';
						emptyEl.hidden = false;
						return;
					}
					var html = '';
					groups.forEach(function (group) {
						html += '<div class="twd-ap-articles-group">' +
							'<div class="twd-ap-articles-group-head">' +
								'<h2 class="twd-ap-articles-group-title">' + escapeHtml(group.category.name) + '</h2>' +
								(group.total > group.posts.length
									? '<button type="button" class="twd-ap-articles-group-more" data-slug="' + escapeHtml(group.category.slug || '') + '">See all</button>'
									: '') +
							'</div>' +
							'<div class="twd-ap-articles-grid" style="--twd-ap-articles-columns: 3;">' +
								group.posts.map(cardHtml).join('') +
							'</div>' +
						'</div>';
					});
					groupsEl.innerHTML = html;

					groupsEl.querySelectorAll('.twd-ap-articles-group-more').forEach(function (btn) {
						btn.addEventListener('click', function () {
							state.category = btn.dataset.slug;
							state.offset = 0;
							if (selectEl) { selectEl.value = state.category; }
							fetchArticles(true);
							root.scrollIntoView({ behavior: 'smooth', block: 'start' });
						});
					});
				})
				.catch(function () {
					state.loading = false;
					groupsEl.innerHTML = '';
				});
		}

		function fetchArticles(replace) {
			if (state.loading) {
				return;
			}
			state.loading = true;
			loadMoreBtn.textContent = 'Loading…';
			groupsEl.innerHTML = '';
			gridEl.hidden = false;
			// A fresh list (new filter/search, or the very first load) has
			// nothing on screen yet to keep shape while it fetches, so
			// skeleton cards go up immediately instead of an empty grid
			// popping into a full one. "Load more" leaves what's already
			// showing alone and just appends below it.
			if (replace) {
				gridEl.innerHTML = skeletonCardsHtml(config.count);
			}

			var params = ['per_page=' + encodeURIComponent(config.count), 'offset=' + encodeURIComponent(state.offset)];
			if (state.search) {
				params.push('search=' + encodeURIComponent(state.search));
			}
			if (state.category) {
				params.push('category=' + encodeURIComponent(state.category));
			}
			if (state.tag) {
				params.push('tag=' + encodeURIComponent(state.tag));
			}

			fetch(config.restUrl + '/articles?' + params.join('&'), { cache: 'no-store' })
				.then(function (r) {
					return r.json();
				})
				.then(function (data) {
					state.loading = false;
					loadMoreBtn.textContent = 'Load more';

					if (replace) {
						gridEl.innerHTML = '';
					}
					var items = data.items || [];
					items.forEach(function (item) {
						gridEl.insertAdjacentHTML('beforeend', cardHtml(item));
					});

					var hasResults = gridEl.children.length > 0;
					emptyEl.hidden = hasResults;
					gridEl.hidden = !hasResults;

					// manyArticles is a hard gate on top of has_more, not just a
					// per_page bump meant to make has_more come back false on
					// its own: relying on that bump alone means a wrong (e.g.
					// stale-cached) total_articles count could still leave
					// Load more showing on a small site. This way it never
					// can, whatever total_articles actually reported.
					loadMoreBtn.hidden = !state.manyArticles || !data.has_more;
				})
				.catch(function () {
					state.loading = false;
					loadMoreBtn.textContent = 'Load more';
					if (replace) {
						gridEl.innerHTML = '';
						gridEl.hidden = true;
					}
				});
		}

		function cardHtml(item) {
			var thumb = state.showThumbnails
				? (item.thumbnail
					? '<span class="twd-ap-article-thumb" style="background-image:url(\'' + escapeUrl(item.thumbnail) + '\')"></span>'
					: '<span class="twd-ap-article-thumb twd-ap-article-thumb-placeholder" aria-hidden="true">' + PLACEHOLDER_SVG + '</span>')
				: '';
			var eyebrow = item.category ? escapeHtml(item.category) + ' &middot; ' : '';

			return '<a class="twd-ap-article-card" href="' + escapeHtml(item.link) + '">' +
				thumb +
				'<span class="twd-ap-article-body">' +
					'<span class="twd-ap-article-date">' + eyebrow + escapeHtml(item.date) + ' &middot; ' + parseInt(item.reading_time, 10) + ' min read</span>' +
					'<span class="twd-ap-article-title">' + escapeHtml(item.title) + '</span>' +
					'<span class="twd-ap-article-excerpt">' + escapeHtml(item.excerpt) + '</span>' +
					'<span class="twd-ap-article-readmore">Read more</span>' +
				'</span>' +
			'</a>';
		}
	}

	// -- Admin "Customise this grid" popup: category order (drag to reorder),
	// how many categories/posts to show, and the thumbnails toggle. Opened
	// per grid instance, but the settings it saves are site-wide.
	function openGridSettings(root, config, onSaved) {
		var overlay = document.querySelector('.twd-ap-grid-settings-overlay[data-for="' + root.id + '"]');
		if (!overlay) { return; }

		var closeBtn   = overlay.querySelector('.twd-ap-grid-settings-close');
		var catsCount  = overlay.querySelector('#twd-ap-gs-cats-count');
		var postsCount = overlay.querySelector('#twd-ap-gs-posts-count');
		var thumbsBox  = overlay.querySelector('#twd-ap-gs-thumbnails');
		var colorInput = overlay.querySelector('#twd-ap-gs-readmore-color');
		var accentColorInput = overlay.querySelector('#twd-ap-gs-accent-color');
		// Not applied via a CSS var on `root` like the other two colours --
		// the swipe book button it styles lives on every article page, not
		// just pages carrying this grid, so it's set server-side inline by
		// TWD_AP_Swipebook::append_button() instead. This picker only reads
		// and saves the value.
		var swipebookColorInput = overlay.querySelector('#twd-ap-gs-swipebook-color');
		var sbHeadingInput = overlay.querySelector('#twd-ap-gs-sb-heading');
		var sbLabelInput = overlay.querySelector('#twd-ap-gs-sb-label');
		var sbLogoBgSelect = overlay.querySelector('#twd-ap-gs-sb-logo-bg');
		var sbExportBrandingBox = overlay.querySelector('#twd-ap-gs-sb-export-branding');
		var orderList  = overlay.querySelector('#twd-ap-gs-cat-order');
		var saveBtn    = overlay.querySelector('#twd-ap-gs-save');
		var statusEl   = overlay.querySelector('#twd-ap-grid-settings-status');

		var photoPreview = overlay.querySelector('#twd-ap-gs-profile-photo-preview');
		var photoSelect  = overlay.querySelector('#twd-ap-gs-profile-photo-select');
		var photoRemove  = overlay.querySelector('#twd-ap-gs-profile-photo-remove');
		var nameInput    = overlay.querySelector('#twd-ap-gs-profile-name');
		var bioInput     = overlay.querySelector('#twd-ap-gs-profile-bio');
		var linkUrlInput = overlay.querySelector('#twd-ap-gs-profile-link-url');
		var linkLabelInput = overlay.querySelector('#twd-ap-gs-profile-link-label');
		var profilePhotoId = 0;
		var profileFrame = null;

		function renderPhotoPreview(url) {
			if (url) {
				photoPreview.style.backgroundImage = 'url(' + url + ')';
				photoRemove.hidden = false;
			} else {
				photoPreview.style.backgroundImage = '';
				photoRemove.hidden = true;
			}
		}

		photoSelect.addEventListener('click', function () {
			if (!window.wp || !wp.media) { return; }
			if (!profileFrame) {
				profileFrame = wp.media({ title: 'Choose Profile Photo', multiple: false, library: { type: 'image' } });
				profileFrame.on('select', function () {
					var att = profileFrame.state().get('selection').first().toJSON();
					profilePhotoId = att.id;
					var url = (att.sizes && att.sizes.medium) ? att.sizes.medium.url : att.url;
					renderPhotoPreview(url);
				});
			}
			profileFrame.open();
		});
		photoRemove.addEventListener('click', function () {
			profilePhotoId = 0;
			renderPhotoPreview('');
		});

		var sbLogoPreview = overlay.querySelector('#twd-ap-gs-sb-logo-preview');
		var sbLogoSelect  = overlay.querySelector('#twd-ap-gs-sb-logo-select');
		var sbLogoRemove  = overlay.querySelector('#twd-ap-gs-sb-logo-remove');
		var sbLogoId = 0;
		var sbLogoFrame = null;

		function renderSbLogoPreview(url) {
			if (url) {
				sbLogoPreview.style.backgroundImage = 'url(' + url + ')';
				sbLogoRemove.hidden = false;
			} else {
				sbLogoPreview.style.backgroundImage = '';
				sbLogoRemove.hidden = true;
			}
		}

		sbLogoSelect.addEventListener('click', function () {
			if (!window.wp || !wp.media) { return; }
			if (!sbLogoFrame) {
				sbLogoFrame = wp.media({ title: 'Choose Summary Book Logo', multiple: false, library: { type: 'image' } });
				sbLogoFrame.on('select', function () {
					var att = sbLogoFrame.state().get('selection').first().toJSON();
					sbLogoId = att.id;
					var url = (att.sizes && att.sizes.medium) ? att.sizes.medium.url : att.url;
					renderSbLogoPreview(url);
				});
			}
			sbLogoFrame.open();
		});
		sbLogoRemove.addEventListener('click', function () {
			sbLogoId = 0;
			renderSbLogoPreview('');
		});

		function close() {
			overlay.hidden = true;
		}
		closeBtn.addEventListener('click', close);
		overlay.addEventListener('click', function (e) {
			if (e.target === overlay) { close(); }
		});

		function setStatus(msg, ok) {
			statusEl.textContent = msg;
			statusEl.hidden = !msg;
			statusEl.classList.toggle('twd-ap-status-ok', !!ok);
		}

		function renderOrderList(categories) {
			orderList.innerHTML = '';
			categories.forEach(function (cat) {
				var li = document.createElement('li');
				li.className = 'twd-ap-gs-cat-row';
				li.draggable = true;
				li.dataset.id = cat.id;
				li.innerHTML = '<span class="twd-ap-gs-drag-handle" aria-hidden="true">&#8942;&#8942;</span><span>' + escapeHtml(cat.name) + '</span>';
				orderList.appendChild(li);
			});
		}

		var dragging = null;
		orderList.addEventListener('dragstart', function (e) {
			var li = e.target.closest('.twd-ap-gs-cat-row');
			if (!li) { return; }
			dragging = li;
			li.classList.add('is-dragging');
		});
		orderList.addEventListener('dragend', function () {
			if (dragging) { dragging.classList.remove('is-dragging'); }
			dragging = null;
		});
		orderList.addEventListener('dragover', function (e) {
			e.preventDefault();
			var after = getDragAfterElement(orderList, e.clientY);
			if (!dragging) { return; }
			if (after == null) {
				orderList.appendChild(dragging);
			} else {
				orderList.insertBefore(dragging, after);
			}
		});

		function getDragAfterElement(container, y) {
			var rows = Array.prototype.slice.call(container.querySelectorAll('.twd-ap-gs-cat-row:not(.is-dragging)'));
			var closest = { offset: -Infinity, element: null };
			rows.forEach(function (row) {
				var box = row.getBoundingClientRect();
				var offset = y - box.top - box.height / 2;
				if (offset < 0 && offset > closest.offset) {
					closest = { offset: offset, element: row };
				}
			});
			return closest.element;
		}

		fetch(config.restUrl + '/grid-settings', { cache: 'no-store' })
			.then(function (r) { return r.json(); })
			.then(function (data) {
				catsCount.value = data.categories_count || 4;
				postsCount.value = data.posts_per_category || 6;
				thumbsBox.checked = false !== data.show_thumbnails;
				colorInput.value = data.read_more_color || '#1d4ed8';
				accentColorInput.value = data.accent_color || '#2563eb';
				swipebookColorInput.value = data.swipebook_color || '#5b8a72';
				sbHeadingInput.value = data.swipebook_heading || '';
				sbLabelInput.value = data.swipebook_label || '';
				sbLogoBgSelect.value = data.swipebook_logo_bg || 'light';
				sbExportBrandingBox.checked = false !== data.swipebook_export_branding;
				sbLogoId = data.swipebook_logo_id || 0;
				renderSbLogoPreview(data.swipebook_logo_url || '');
				renderOrderList(data.categories || []);
				profilePhotoId = data.profile_photo_id || 0;
				renderPhotoPreview(data.profile_photo_url || '');
				nameInput.value = data.profile_name || '';
				bioInput.value = data.profile_bio || '';
				linkUrlInput.value = data.profile_link_url || '';
				linkLabelInput.value = data.profile_link_label || '';
				overlay.hidden = false;
			})
			.catch(function () {
				overlay.hidden = false;
			});

		saveBtn.onclick = function () {
			var order = Array.prototype.map.call(orderList.querySelectorAll('.twd-ap-gs-cat-row'), function (li) {
				return parseInt(li.dataset.id, 10);
			});
			var payload = {
				categories_count: parseInt(catsCount.value, 10) || 4,
				posts_per_category: parseInt(postsCount.value, 10) || 6,
				show_thumbnails: !!thumbsBox.checked,
				read_more_color: colorInput.value,
				accent_color: accentColorInput.value,
				swipebook_color: swipebookColorInput.value,
				swipebook_heading: sbHeadingInput.value,
				swipebook_label: sbLabelInput.value,
				swipebook_logo_id: sbLogoId,
				swipebook_logo_bg: sbLogoBgSelect.value,
				swipebook_export_branding: !!sbExportBrandingBox.checked,
				category_order: order,
				profile_photo_id: profilePhotoId,
				profile_name: nameInput.value,
				profile_bio: bioInput.value,
				profile_link_url: linkUrlInput.value,
				profile_link_label: linkLabelInput.value,
			};

			setStatus('Saving…', false);
			fetch(config.restUrl + '/grid-settings', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': config.nonce },
				body: JSON.stringify(payload),
			})
				.then(function (r) { return r.json().then(function (d) { return { ok: r.ok, data: d }; }); })
				.then(function (result) {
					if (!result.ok) {
						setStatus('Could not save. Please try again.', false);
						return;
					}
					setStatus('Saved.', true);
					if (onSaved) { onSaved(); }
					setTimeout(close, 700);
				})
				.catch(function () {
					setStatus('Could not save. Please try again.', false);
				});
		};
	}

	function escapeHtml(str) {
		var div = document.createElement('div');
		div.textContent = str == null ? '' : String(str);
		return div.innerHTML;
	}

	function escapeUrl(str) {
		return escapeHtml(str).replace(/'/g, '%27');
	}
})();
